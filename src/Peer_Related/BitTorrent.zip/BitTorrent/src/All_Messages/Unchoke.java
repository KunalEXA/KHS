package All_Messages;

public class Unchoke extends Message {

    public Unchoke() {
        super ("Unchoke");
    }
}
