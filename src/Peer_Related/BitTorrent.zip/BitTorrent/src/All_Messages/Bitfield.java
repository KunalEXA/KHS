
package All_Messages;

public class Bitfield extends Message {

    Bitfield (byte[] bitfield) {
        super ("Bitfield", bitfield);
    }



}
