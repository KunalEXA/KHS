
package All_Messages;
public class Request extends Message {

    Request (byte[] pieceIdx)
    {

        super ("Request", pieceIdx);
    }

}
