package All_Messages;

public class Piece extends Message {

    Piece (byte[] payload) {
        super ("Piece", payload);
    }


    }

