package All_Messages;
public class Interested  extends Message {

    public Interested() {
        super ("Interested");
    }
}
