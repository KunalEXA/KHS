
package All_Messages;
public class Uninterested  extends Message {

    public Uninterested() {
        super ("Uninterested");
    }
}
