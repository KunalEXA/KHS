
package All_Messages;

public class Choke extends Message {

    public Choke(){
        super ("Choke");

    }
}
